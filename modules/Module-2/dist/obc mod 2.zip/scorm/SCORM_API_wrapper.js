(function () {
  var root = window;
  var pipwerks = root.pipwerks = root.pipwerks || {};
  var scorm = pipwerks.SCORM = pipwerks.SCORM || {};

  scorm.version = scorm.version || "1.2";
  scorm.API = scorm.API || { handle: null };
  scorm.connection = scorm.connection || { isActive: false };

  function isSuccess(value) {
    return value === true || value === "true" || value === "1" || value === 1;
  }

  function getApiName() {
    return scorm.version === "2004" ? "API_1484_11" : "API";
  }

  function findApi(win, apiName, depth) {
    if (!win || depth > 50) return null;

    try {
      if (win[apiName]) {
        return win[apiName];
      }
    } catch (error) {
      return null;
    }

    try {
      if (win.parent && win.parent !== win) {
        return findApi(win.parent, apiName, depth + 1);
      }
    } catch (error) {
      return null;
    }

    return null;
  }

  function getApi() {
    var apiName = getApiName();

    if (scorm.API.handle) {
      return scorm.API.handle;
    }

    var api = findApi(root, apiName, 0);

    if (!api) {
      try {
        if (root.opener) {
          api = findApi(root.opener, apiName, 0);
        }
      } catch (error) {
        api = null;
      }
    }

    scorm.API.handle = api || null;
    return scorm.API.handle;
  }

  function call(method, fallback, args) {
    var api = getApi();
    if (!api || typeof api[method] !== "function") {
      return fallback;
    }

    try {
      return api[method].apply(api, args || []);
    } catch (error) {
      return fallback;
    }
  }

  scorm.init = function () {
    if (scorm.connection.isActive) {
      return true;
    }

    scorm.API.handle = null;
    var result = scorm.version === "2004"
      ? call("Initialize", "false", [""])
      : call("LMSInitialize", "false", [""]);

    scorm.connection.isActive = isSuccess(result);
    return scorm.connection.isActive;
  };

  scorm.get = function (parameter) {
    if (!scorm.connection.isActive && !scorm.init()) {
      return "";
    }

    return scorm.version === "2004"
      ? call("GetValue", "", [parameter])
      : call("LMSGetValue", "", [parameter]);
  };

  scorm.set = function (parameter, value) {
    if (!scorm.connection.isActive && !scorm.init()) {
      return false;
    }

    var result = scorm.version === "2004"
      ? call("SetValue", "false", [parameter, value])
      : call("LMSSetValue", "false", [parameter, value]);

    return isSuccess(result);
  };

  scorm.save = function () {
    if (!scorm.connection.isActive && !scorm.init()) {
      return false;
    }

    var result = scorm.version === "2004"
      ? call("Commit", "false", [""])
      : call("LMSCommit", "false", [""]);

    return isSuccess(result);
  };

  scorm.quit = function () {
    if (!scorm.connection.isActive && !scorm.init()) {
      return false;
    }

    var result = scorm.version === "2004"
      ? call("Terminate", "false", [""])
      : call("LMSFinish", "false", [""]);

    scorm.connection.isActive = false;
    return isSuccess(result);
  };
})();